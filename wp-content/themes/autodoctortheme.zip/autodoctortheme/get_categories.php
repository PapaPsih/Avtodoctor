<?php
/**
* @package WordPress
* @subpackage clean
* Template name: ���������
*/
?>
    <?php include "header.php"; ?>

            <div class="content-main">
                <div class="wrap-center">
                    <ul class="breadcrumb">
                        <li>
                            <a href="#">��������-������� Autodoctor &rarr;
                            </a>
                        </li>
                        <li class="active">������� �����</li>
                    </ul>
                    <div class="main-title">
                        <span>������� �����
                            <i>256</i>
                        </span>
                    </div>
                    <div class="sorting">
                        <div class="row">
                            <div class="col">
                                <select class="select-inp" data-placeholder="��� �������">
                                    <option></option>
                                    <option value="WY">��� �������</option>
                                    <option value="AL">��� �������</option>
                                    <option value="AL">��� �������</option>
                                </select>
                            </div>
                            <div class="col">
                                <select class="select-inp" data-placeholder="�����">
                                    <option></option>
                                    <option value="WY">�����</option>
                                    <option value="AL">�����</option>
                                    <option value="AL">�����</option>
                                </select>
                            </div>
                            <div class="col">
                                <select class="select-inp" data-placeholder="������">
                                    <option></option>
                                    <option value="WY">������</option>
                                    <option value="AL">������</option>
                                    <option value="AL">������</option>
                                </select>
                            </div>
                            <div class="col">
                                <select class="select-inp" data-placeholder="�����������">
                                    <option></option>
                                    <option value="WY">�����������</option>
                                    <option value="AL">�����������</option>
                                    <option value="AL">�����������</option>
                                </select>
                            </div>
                            <div class="col">
                                <a href="#" class="btn btn_dang">���������</a>
                            </div>
                        </div>
                        <div class="item">
                            <div class="col">
                                <p>��������:</p>
                                <select class="select-inp" data-placeholder="�� ������� � �������">
                                    <option></option>
                                    <option value="WY">�����������</option>
                                    <option value="AL">�����������</option>
                                    <option value="AL">�����������</option>
                                </select>
                            </div>
                            <div class="col col_2 align-right">
                                <p>���:</p>
                                <select class="select-inp" data-placeholder="�������">
                                    <option></option>
                                    <option value="WY">�����������</option>
                                    <option value="AL">�����������</option>
                                    <option value="AL">�����������</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <!-- sorting end-->
                    <div class="brand-content">
                        <div class="brand-directory">
                            <div class="col col_25 active-product">
                                <div class="info-a there">
                                    <span>���� � �������</span>
                                </div>
                                <div class="img">
                                    <img src="static/img/content/243x207.jpg" alt="logo" />
                                </div>
                                <div class="wrap-info">
                                    <div class="title">
                                        <span>������� ����� Chevrolet Aveo Epica. ������� ����� ��������</span>
                                    </div>
                                    <div class="price">
                                        <i>����:</i>
                                        <b>3 580</b>
                                        <i>���</i>
                                    </div>
                                    <div class="buy">
                                        <a href="#" class="btn btn_dang">������</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col col_25">
                                <div class="info-a none">
                                    <span>��� � �������</span>
                                </div>
                                <div class="img">
                                    <img src="static/img/content/243x207.jpg" alt="logo" />
                                </div>
                                <div class="wrap-info">
                                    <div class="title">
                                        <span>������� ����� Chevrolet Aveo Epica. ������� ����� ��������</span>
                                    </div>
                                    <div class="price">
                                        <i>����:</i>
                                        <b>3 580</b>
                                        <i>���</i>
                                    </div>
                                    <div class="buy">
                                        <a href="#" class="btn btn_dang">������</a>
                                    </div>

                                </div>
                            </div>
                            <div class="col col_25">
                                <div class="info-a stock">
                                    <span>�����</span>
                                </div>
                                <div class="img">
                                    <img src="static/img/content/243x207.jpg" alt="logo" />
                                </div>
                                <div class="wrap-info">
                                    <div class="title">
                                        <span>������� ����� Chevrolet Aveo Epica. ������� ����� ��������</span>
                                    </div>
                                    <div class="price">
                                        <i>����:</i>
                                        <b>3 580</b>
                                        <i>���</i>
                                    </div>
                                    <div class="buy">
                                        <a href="#" class="btn btn_dang">������</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col col_25">
                                <div class="info-a there">
                                    <span>���� � �������</span>
                                </div>
                                <div class="img">
                                    <img src="static/img/content/243x207.jpg" alt="logo" />
                                </div>
                                <div class="wrap-info">
                                    <div class="title">
                                        <span>������� ����� Chevrolet Aveo Epica. ������� ����� ��������</span>
                                    </div>
                                    <div class="price">
                                        <i>����:</i>
                                        <b>3 580</b>
                                        <i>���</i>
                                    </div>
                                    <div class="buy">
                                        <a href="#" class="btn btn_dang">������</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col col_25">
                                <div class="info-a there">
                                    <span>���� � �������</span>
                                </div>
                                <div class="img">
                                    <img src="static/img/content/243x207.jpg" alt="logo" />
                                </div>
                                <div class="wrap-info">
                                    <div class="title">
                                        <span>������� ����� Chevrolet Aveo Epica. ������� ����� ��������</span>
                                    </div>
                                    <div class="price">
                                        <i>����:</i>
                                        <b>3 580</b>
                                        <i>���</i>
                                    </div>
                                    <div class="buy">
                                        <a href="#" class="btn btn_dang">������</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col col_25">
                                <div class="info-a none">
                                    <span>��� � �������</span>
                                </div>
                                <div class="img">
                                    <img src="static/img/content/243x207.jpg" alt="logo" />
                                </div>
                                <div class="wrap-info">
                                    <div class="title">
                                        <span>������� ����� Chevrolet Aveo Epica. ������� ����� ��������</span>
                                    </div>
                                    <div class="price">
                                        <i>����:</i>
                                        <b>3 580</b>
                                        <i>���</i>
                                    </div>
                                    <div class="buy">
                                        <a href="#" class="btn btn_dang">������</a>
                                    </div>

                                </div>
                            </div>
                            <div class="col col_25">
                                <div class="info-a stock">
                                    <span>�����</span>
                                </div>
                                <div class="img">
                                    <img src="static/img/content/243x207.jpg" alt="logo" />
                                </div>
                                <div class="wrap-info">
                                    <div class="title">
                                        <span>������� ����� Chevrolet Aveo Epica. ������� ����� ��������</span>
                                    </div>
                                    <div class="price">
                                        <i>����:</i>
                                        <b>3 580</b>
                                        <i>���</i>
                                    </div>
                                    <div class="buy">
                                        <a href="#" class="btn btn_dang">������</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col col_25">
                                <div class="info-a there">
                                    <span>���� � �������</span>
                                </div>
                                <div class="img">
                                    <img src="static/img/content/243x207.jpg" alt="logo" />
                                </div>
                                <div class="wrap-info">
                                    <div class="title">
                                        <span>������� ����� Chevrolet Aveo Epica. ������� ����� ��������</span>
                                    </div>
                                    <div class="price">
                                        <i>����:</i>
                                        <b>3 580</b>
                                        <i>���</i>
                                    </div>
                                    <div class="buy">
                                        <a href="#" class="btn btn_dang">������</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col col_25">
                                <div class="info-a there">
                                    <span>���� � �������</span>
                                </div>
                                <div class="img">
                                    <img src="static/img/content/243x207.jpg" alt="logo" />
                                </div>
                                <div class="wrap-info">
                                    <div class="title">
                                        <span>������� ����� Chevrolet Aveo Epica. ������� ����� ��������</span>
                                    </div>
                                    <div class="price">
                                        <i>����:</i>
                                        <b>3 580</b>
                                        <i>���</i>
                                    </div>
                                    <div class="buy">
                                        <a href="#" class="btn btn_dang">������</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col col_25">
                                <div class="info-a none">
                                    <span>��� � �������</span>
                                </div>
                                <div class="img">
                                    <img src="static/img/content/243x207.jpg" alt="logo" />
                                </div>
                                <div class="wrap-info">
                                    <div class="title">
                                        <span>������� ����� Chevrolet Aveo Epica. ������� ����� ��������</span>
                                    </div>
                                    <div class="price">
                                        <i>����:</i>
                                        <b>3 580</b>
                                        <i>���</i>
                                    </div>
                                    <div class="buy">
                                        <a href="#" class="btn btn_dang">������</a>
                                    </div>

                                </div>
                            </div>
                            <div class="col col_25">
                                <div class="info-a stock">
                                    <span>�����</span>
                                </div>
                                <div class="img">
                                    <img src="static/img/content/243x207.jpg" alt="logo" />
                                </div>
                                <div class="wrap-info">
                                    <div class="title">
                                        <span>������� ����� Chevrolet Aveo Epica. ������� ����� ��������</span>
                                    </div>
                                    <div class="price">
                                        <i>����:</i>
                                        <b>3 580</b>
                                        <i>���</i>
                                    </div>
                                    <div class="buy">
                                        <a href="#" class="btn btn_dang">������</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col col_25">
                                <div class="info-a there">
                                    <span>���� � �������</span>
                                </div>
                                <div class="img">
                                    <img src="static/img/content/243x207.jpg" alt="logo" />
                                </div>
                                <div class="wrap-info">
                                    <div class="title">
                                        <span>������� ����� Chevrolet Aveo Epica. ������� ����� ��������</span>
                                    </div>
                                    <div class="price">
                                        <i>����:</i>
                                        <b>3 580</b>
                                        <i>���</i>
                                    </div>
                                    <div class="buy">
                                        <a href="#" class="btn btn_dang">������</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--brand-directory end-->
                    </div>
                    <!-- brand-content end-->
                    <div class="more-preloader">
                        <a href="#">
                            <span class="more"></span>
                            <p>��������� ������ ��������</p>
                        </a>
                    </div>
                    <div class="pagination-wrap">
                        <nav>
                            <ul class="pagination">
                                <li class="active">
                                    <a href="#">1</a>
                                </li>
                                <li>
                                    <a href="#">2</a>
                                </li>
                                <li>
                                    <a href="#">3</a>
                                </li>
                                <li>
                                    <a href="#">4</a>
                                </li>
                                <li>
                                    <a href="#">5</a>
                                </li>
                                <li>
                                    <a href="#">...</a>
                                </li>
                                <li>
                                    <a href="#">21</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                    <!-- pagination-wrap end-->
                </div>
                <!-- wrap-center end-->
            </div>
            <?php include "footer.php"; ?>
        </div>
    </div>


</body>