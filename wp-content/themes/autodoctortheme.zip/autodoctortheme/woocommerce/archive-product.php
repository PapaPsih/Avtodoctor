<?php
/**
 * The Template for displaying product archives, including the main shop page which is a post type archive.
 *
 * Override this template by copying it to yourtheme/woocommerce/archive-product.php
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $wp_query;
// get the query object
$cat_obj = $wp_query->get_queried_object();
  
if($cat_obj)    {
    $category_ID  = $cat_obj->term_id;
}

$term = get_term( $category_ID, 'product_cat' );


get_header( 'shop' ); ?>

		<div class="content-main">
                <div class="wrap-center">
                    <ul class="breadcrumb">
                        <li>
                            <a href="#">Интернет-магазин Autodoctor &rarr;
                            </a>
                        </li>
                        <li class="active"><?php woocommerce_page_title(); ?></li>
                    </ul>
                    <div class="main-title">
                        <span><?php woocommerce_page_title(); ?>
                            <i><?php echo $term->count; ?></i>
                        </span>
                    </div>
                    <div class="sorting">
                        <div class="row">
                            <div class="col">
                                <select class="select-inp" data-placeholder="Год выпуска">
                                    <option></option>
                                    <option value="WY">Год выпуска</option>
                                    <option value="AL">Год выпуска</option>
                                    <option value="AL">Год выпуска</option>
                                </select>
                            </div>
                            <div class="col">
                                <select class="select-inp" data-placeholder="Марка">
                                    <option></option>
                                    <option value="WY">Марка</option>
                                    <option value="AL">Марка</option>
                                    <option value="AL">Марка</option>
                                </select>
                            </div>
                            <div class="col">
                                <select class="select-inp" data-placeholder="Модель">
                                    <option></option>
                                    <option value="WY">Модель</option>
                                    <option value="AL">Модель</option>
                                    <option value="AL">Модель</option>
                                </select>
                            </div>
                            <div class="col">
                                <select class="select-inp" data-placeholder="Модификация">
                                    <option></option>
                                    <option value="WY">Модификация</option>
                                    <option value="AL">Модификация</option>
                                    <option value="AL">Модификация</option>
                                </select>
                            </div>
                            <div class="col">
                                <a href="#" class="btn btn_dang">Подобрать</a>
                            </div>
                        </div>
                        <div class="item">
                            <div class="col">
                                <p>Выводить:</p>
                                <select class="select-inp" data-placeholder="от дешевых к дорогим">
                                    <option></option>
                                    <option value="WY">Модификация</option>
                                    <option value="AL">Модификация</option>
                                    <option value="AL">Модификация</option>
                                </select>
                            </div>
                            <div class="col col_2 align-right">
                                <p>Вид:</p>
                                <select class="select-inp" data-placeholder="списком">
                                    <option></option>
                                    <option value="WY">Модификация</option>
                                    <option value="AL">Модификация</option>
                                    <option value="AL">Модификация</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <!-- sorting end-->
                    <div class="brand-content">
                        <div class="brand-directory">
                        	<?php woocommerce_product_loop_start(); ?>

								<?php woocommerce_product_subcategories(); ?>

								<?php while ( have_posts() ) : the_post(); ?>

									<?php wc_get_template_part( 'content', 'product' ); ?>

								<?php endwhile; // end of the loop. ?>

							<?php woocommerce_product_loop_end(); ?>
                        </div>
                        <!--brand-directory end-->
                    </div>
                    <!-- brand-content end-->
                    <div class="more-preloader">
                        <a href="#">
                            <span class="more"></span>
                            <p>Загрузить больше новостей</p>
                        </a>
                    </div>
                    <div class="pagination-wrap">
                        <nav>
                            <ul class="pagination">
                                <li class="active">
                                    <a href="#">1</a>
                                </li>
                                <li>
                                    <a href="#">2</a>
                                </li>
                                <li>
                                    <a href="#">3</a>
                                </li>
                                <li>
                                    <a href="#">4</a>
                                </li>
                                <li>
                                    <a href="#">5</a>
                                </li>
                                <li>
                                    <a href="#">...</a>
                                </li>
                                <li>
                                    <a href="#">21</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                    <!-- pagination-wrap end-->
                </div>
                <!-- wrap-center end-->
            </div>
        </div>
    </div>

<?php get_footer( 'shop' ); ?>
