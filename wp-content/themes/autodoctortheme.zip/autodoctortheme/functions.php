<?php
	require_once('LiqPay.php');

	add_action('wp_ajax_send_sms', 'send_sms_by_turbo_sms');
	add_action('wp_ajax_nopriv_send_sms', 'send_sms_by_turbo_sms');

	add_action('wp_ajax_get_liqpay_button', 'reset_liqpay_form');
	add_action('wp_ajax_nopriv_get_liqpay_button', 'reset_liqpay_form');

	add_action('wp_ajax_send_one_email', 'send_one_email_by_mailgun');
	add_action('wp_ajax_nopriv_send_one_email', 'send_one_email_by_mailgun');

	add_action('wp_ajax_subscribe', 'subscribe_autodoctor');
	add_action('wp_ajax_nopriv_subscribe', 'subscribe_autodoctor');

	add_action('wp_ajax_get_newletters_list', 'get_newletters_list_autodoctor');
	add_action('wp_ajax_nopriv_get_newletters_list', 'get_newletters_list_autodoctor');

	add_action('wp_ajax_get_subscribers_list', 'get_subscribers_list_autodoctor');
	add_action('wp_ajax_nopriv_get_subscribers_list', 'get_subscribers_list_autodoctor');

	add_action('wp_ajax_send_all_subscribers', 'send_all_subscribers_autodoctor');
	add_action('wp_ajax_nopriv_send_all_subscribers', 'send_all_subscribers_autodoctor');

	add_action('wp_ajax_get_news', 'get_news_autodoctor');
	add_action('wp_ajax_nopriv_get_news', 'get_news_autodoctor');

	function get_news_autodoctor(){
		$args_count = array(
                    'category' => '7,8'
                );
        $posts_count = get_posts( $args );

        if(!$_POST['offset']){
        	$offset = ( $_POST['page'] * 20 ) - 20;
        }else{
        	$offset = ( ( $_POST['page'] * 20 ) - 20 ) + $_POST['offset'];
        }
        $args = array(
                    'posts_per_page' => 20,
                    'category' => '7,8',
                    'offset' => $offset
                );
        $posts_array = get_posts( $args );
        $news_array = array('data' => array(),
        					'all_count' => count($posts_count));
        foreach ( $posts_array as $post ){
        	$post_categories = wp_get_post_categories( $post->ID );
				
			$cat = get_category( $post_categories[0] );
				
            if($cat->cat_ID == 7){
            	$one_new_ui = create_new_ui($post, 50);
            }else{
            	$one_new_ui = create_new_ui($post, 25);
            }           
            $news_array['data'][] = array('category' => $cat->cat_ID == 7 ? 'big' : 'little',
                                  		  'new' => $one_new_ui);                                 
        } //end foreach
        echo json_encode($news_array);
        wp_die();
	}

	function create_new_ui($post, $size){
		$one_new_ui = '<div data-id = "' . $post->ID . '" data-type = "news" class="col col_' . $size . '">
                        <a href="' . get_option('home') . '/all-news/new/?new=' . $post->ID . '">
                          <div class="img">'; 
        if (wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), full )) {
            $image_source = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), full );
            $one_new_ui .= '<img src="' . $image_source[0] . '" alt="thumbnail" />';
        }
        else {
            $one_new_ui .= '<img src="' . get_bloginfo('template_directory') . '/static/img/content/243x189.jpg' . '" alt="thumbnail" />';
        }
        $one_new_ui .= '</div>
                        <div class="wrap-text">
                            
                                <div class="text">
                                    <p>' . $post->post_title . '</p>
                                </div>
                                <div class="data">
                                    <div class="item">
                                        <span>Новости</span>
                                    </div>
                                    <div class="item">
                                        <span>' . get_the_date( 'd.m.y', $post->ID ) . '</span>
                                    </div>
                                </div>                                                            
                            </div>
                        </a>
                    </div>';
        return $one_new_ui;
	}

	function create_article_ui($post, $size){
		$one_new_ui = '<div data-id = "' . $post->ID . '" data-type = "articles" class="col col_' . $size . '">
                        <a href="' . get_option('home') . '/all-articles/article/?article=' . $post->ID . '">
                          <div class="img">'; 
        if (wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), full )) {
            $image_source = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), full );
            $one_new_ui .= '<img src="' . $image_source[0] . '" alt="thumbnail" />';
        }
        else {
            $one_new_ui .= '<img src="' . get_bloginfo('template_directory') . '/static/img/content/243x189.jpg' . '" alt="thumbnail" />';
        }
        $one_new_ui .= '</div>
                        <div class="wrap-text">
                            
                                <div class="text">
                                    <p>' . $post->post_title . '</p>
                                </div>
                                <div class="data">
                                    <div class="item">
                                        <span>Статьи</span>
                                    </div>
                                    <div class="item">
                                        <span>' . get_the_date( 'd.m.y', $post->ID ) . '</span>
                                    </div>
                                </div>                                                            
                            </div>
                        </a>
                    </div>';
        return $one_new_ui;
	}

	function send_sms_by_turbo_sms(){
		$client_number = preg_replace('/\D/', '', $_POST['client_phone']);
	  	if(strlen($client_number) == 10){
	   		$client_number = "38".$client_number;
	  	}
	  	$admin_number = preg_replace('/\D/', '', $_POST['admin_phone']);
	  	if(strlen($admin_number) == 10){
	   		$admin_number = "38".$admin_number;
	  	}
		sendSMS(array('phone' => $client_number,
					  'text' => $_POST['client_text']));
		sendSMS(array('phone' => $admin_number,
					  'text' => $_POST['admin_text']));
		var_dump($_POST);
		wp_die();
	}

	function reset_liqpay_form(){
		$liqpay = new LiqPay('i17896066194', 'rZXNJhTplHVnsNr4GFANPgfW3sKhi5uLpg3Mf2Dc');
		$html = $liqpay->cnb_form(array(
			'version'        => '3',
			'amount'         => (int)$_POST['total_amount'],
			'currency'       => 'UAH',
			'description'    => 'Оплата покупки автодеталей в магазине Autodoctor',
			'order_id'       => time(),
			'server_url'	 => 'http://current.ua/my_orders/autodoctor/wordpress/test_page/',
			'result_url'     => 'http://current.ua/my_orders/autodoctor/wordpress/test_page/?success=1',
			'sandbox'		 => '1',
			'pay_way'		 => 'card, privat24'
		));
		echo $html;
		wp_die();
	}

	function send_one_email_by_mailgun(){
		sendEmail(array('recipient' => $_POST['client_email_registration'],
					  	'subject' => $_POST['client_subject_registration'],
					  	'message' => $_POST['client_message_registration']));
		var_dump($_POST);
		wp_die();
	}

	function subscribe_autodoctor(){
		$result = subscribe_newsletters(array('email' => $_POST['email_subscribe'],
								  			 'id_newsletter' => $_POST['id_newsletter']));
		echo $result;
		wp_die();
	}

	function get_newletters_list_autodoctor(){
		$result = get_newletters_list();
		echo $result;
		wp_die();
	}

	function get_subscribers_list_autodoctor(){
		$result = get_subscribers_list($_POST['id_newsletter']);
		echo $result;
		wp_die();
	}

	function send_all_subscribers_autodoctor(){
		$result = json_decode( get_subscribers_list($_POST['id_newsletter']), true);
		var_dump($_POST['subscribe_text']);		
		for ($i=0; $i < count($result); $i++) { 
			sendEmail(array('recipient' => $result[$i]['email'],
						  	'subject' => $_POST['subscribe_subject'],
						  	'message' => $_POST['subscribe_text']));

		}
		wp_die();
	}