<?php include "header.php"; ?>

            <div class="anchor scroll">
                <i></i>
                <span>Наверх</span>
            </div>
            <div class="content-main">
                <div class="wrap-center">
                    <div class="inf-banner">
                        <div class="close-banner">
                            <span>Спасибо, я уже знаю</span>
                            <a href="#">
                                <i></i>
                            </a>
                        </div>
                        <div class="text">
                            <p>Автодоктор — это коплекс услуг по продаже запчастей и обслуживания на СТО. Вы можете купить у нас запчасть и сразу же установить на нашем СТО.</p>
                        </div>
                    </div>
                    <!-- inf-banner end-->
                    <div class="info-brand">
                        <div class="info-brand__row">
                            <div class="col col_50">
                                <div class="drop-menu">

                                    <ul>
                                        <li>
                                            <a href="#">Chevrolet</a>/</li>
                                        <li>
                                            <a href="#">Toyota</a>/</li>
                                        <li>
                                            <a href="#">BMW</a>/</li>
                                        <li>
                                            <a href="#">Mercedes</a>/</li>
                                        <li>
                                            <a href="#">Fiat</a>/</li>
                                        <li>
                                            <a href="#">Iveco</a>/</li>
                                        <li>
                                            <a href="#">Seat</a>/</li>
                                        <li>
                                            <a href="#">Nissan</a>/</li>
                                        <li>
                                            <a href="#">Opel</a>/</li>
                                        <li>
                                            <a href="#">Audi</a>/</li>
                                        <li>
                                            <a href="#">Chery</a>/</li>
                                        <li>
                                            <a href="#">Hyndai</a>/</li>
                                        <li>
                                            <a href="#">Daewoo</a>/</li>
                                        <li>
                                            <a href="#">Volkswagen</a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="col__i">
                                    <div class="title">
                                        <a href="#">
                                            <span>Рулевое управление</span>
                                        </a>
                                    </div>
                                    <div class="img">
                                        <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/static/img/content/catalog-sample-big0.jpg" alt="logo" />
                                    </div>
                                </div>
                            </div>
                            <div class="col col_50">
                                <div class="drop-menu">

                                    <ul>
                                        <li>
                                            <a href="#">Chevrolet</a>/</li>
                                        <li>
                                            <a href="#">Toyota</a>/</li>
                                        <li>
                                            <a href="#">BMW</a>/</li>
                                        <li>
                                            <a href="#">Mercedes</a>/</li>
                                        <li>
                                            <a href="#">Fiat</a>/</li>
                                        <li>
                                            <a href="#">Iveco</a>/</li>
                                        <li>
                                            <a href="#">Seat</a>/</li>
                                        <li>
                                            <a href="#">Nissan</a>/</li>
                                        <li>
                                            <a href="#">Opel</a>/</li>
                                        <li>
                                            <a href="#">Audi</a>/</li>
                                        <li>
                                            <a href="#">Chery</a>/</li>
                                        <li>
                                            <a href="#">Hyndai</a>/</li>
                                        <li>
                                            <a href="#">Daewoo</a>/</li>
                                        <li>
                                            <a href="#">Volkswagen</a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="col__i">
                                    <div class="title">
                                        <span>Услуги СТО «Автодоктор»</span>
                                    </div>
                                    <div class="img">
                                        <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/static/img/content/catalog-sample-big1.jpg" alt="logo" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- info-brand__row end-->
                        <div class="info-brand__row">
                            <div class="col col_50">
                                <div class="drop-menu">

                                    <ul>
                                        <li>
                                            <a href="#">Chevrolet</a>/</li>
                                        <li>
                                            <a href="#">Toyota</a>/</li>
                                        <li>
                                            <a href="#">BMW</a>/</li>
                                        <li>
                                            <a href="#">Mercedes</a>/</li>
                                        <li>
                                            <a href="#">Fiat</a>/</li>
                                        <li>
                                            <a href="#">Iveco</a>/</li>
                                        <li>
                                            <a href="#">Seat</a>/</li>
                                        <li>
                                            <a href="#">Nissan</a>/</li>
                                        <li>
                                            <a href="#">Opel</a>/</li>
                                        <li>
                                            <a href="#">Audi</a>/</li>
                                        <li>
                                            <a href="#">Chery</a>/</li>
                                        <li>
                                            <a href="#">Hyndai</a>/</li>
                                        <li>
                                            <a href="#">Daewoo</a>/</li>
                                        <li>
                                            <a href="#">Volkswagen</a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="col__i">
                                    <div class="title">
                                        <a href="#">
                                            <span>Тормоза Zimmermann</span>
                                        </a>
                                    </div>
                                    <div class="img">
                                        <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/static/img/content/catalog-sample-big2.jpg" alt="logo" />
                                    </div>
                                </div>
                            </div>
                            <div class="col col_50">
                                <div class="drop-menu">

                                    <ul>
                                        <li>
                                            <a href="#">Chevrolet</a>/</li>
                                        <li>
                                            <a href="#">Toyota</a>/</li>
                                        <li>
                                            <a href="#">BMW</a>/</li>
                                        <li>
                                            <a href="#">Mercedes</a>/</li>
                                        <li>
                                            <a href="#">Fiat</a>/</li>
                                        <li>
                                            <a href="#">Iveco</a>/</li>
                                        <li>
                                            <a href="#">Seat</a>/</li>
                                        <li>
                                            <a href="#">Nissan</a>/</li>
                                        <li>
                                            <a href="#">Opel</a>/</li>
                                        <li>
                                            <a href="#">Audi</a>/</li>
                                        <li>
                                            <a href="#">Chery</a>/</li>
                                        <li>
                                            <a href="#">Hyndai</a>/</li>
                                        <li>
                                            <a href="#">Daewoo</a>/</li>
                                        <li>
                                            <a href="#">Volkswagen</a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="col__i">
                                    <div class="title">
                                        <span>Подвеска H&R</span>
                                    </div>
                                    <div class="img">
                                        <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/static/img/content/catalog-sample-big3.jpg" alt="logo" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- info-brand__row end-->
                        <div class="info-brand__row info-brand__row_title">
                            <div class="col col_25">

                                <div class="col__i">
                                    <div class="title">
                                        <a href="#">
                                            <span>Автостекла</span>
                                        </a>
                                    </div>
                                    <div class="img">
                                        <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/static/img/content/catalog-sample-small0.jpg" alt="logo" />
                                    </div>
                                </div>
                            </div>
                            <div class="col col_25">
                                <div class="col__i">
                                    <div class="title">
                                        <span>Шины</span>
                                    </div>
                                    <div class="img">
                                        <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/static/img/content/catalog-sample-small1.jpg" alt="logo" />
                                    </div>
                                </div>
                            </div>
                            <div class="col col_25">
                                <div class="col__i">
                                    <div class="title">
                                        <span>Автомасла Motul</span>
                                    </div>
                                    <div class="img">
                                        <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/static/img/content/catalog-sample-small2.jpg" alt="logo" />
                                    </div>
                                </div>
                            </div>
                            <div class="col col_25">
                                <div class="col__i">
                                    <div class="title">
                                        <span>Аккумуляторы</span>
                                    </div>
                                    <div class="img">
                                        <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/static/img/content/catalog-sample-small3.jpg" alt="logo" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- info-brand__row end-->
                        <div class="info-brand__row info-brand__row_title">
                            <div class="col col_25">
                                <div class="col__i">
                                    <div class="title">
                                        <a href="#">
                                            <span>GPS-навигаторы</span>
                                        </a>
                                    </div>
                                    <div class="img">
                                        <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/static/img/content/catalog-sample-small4.jpg" alt="logo" />
                                    </div>
                                </div>
                            </div>
                            <div class="col col_25">
                                <div class="col__i">
                                    <div class="title">
                                        <span>Оптика и зеркала</span>
                                    </div>
                                    <div class="img">
                                        <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/static/img/content/catalog-sample-small5.jpg" alt="logo" />
                                    </div>
                                </div>
                            </div>

                            <div class="col col_50">
                                <div class="col__i">
                                    <div class="title">
                                        <span>Диски</span>
                                    </div>
                                    <div class="img">
                                        <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/static/img/content/catalog-sample-big4.jpg" alt="logo" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- info-brand__row end-->
                    </div>
                    <!-- info-brand end-->
                    <div class="reviews-slider">
                        <div class="title">
                            <h3>Отзывы клиентов</h3>
                        </div>
                        <div class="slide">
                            <div class="col">
                                <p>Ремонтировали рейку на моей машине. Понравилось хорошее отношение к клиенту и профессиональный подход к ремонту. На работу дали гарантию и сделали скидку. Буду надеяться, что по вопросу рейки больше не прийдётся искать
                                    мастеров, спасибо!
                                </p>
                                <b>Владимир. Honda Accord</b>
                            </div>
                            <!-- col end-->
                            <div class="col">
                                <p>Ремонтировали рейку на моей машине. Понравилось хорошее отношение к клиенту и профессиональный подход к ремонту. На работу дали гарантию и сделали скидку. Буду надеяться, что по вопросу рейки больше не прийдётся искать
                                    мастеров, спасибо!
                                </p>
                                <b>Владимир. Honda Accord</b>
                            </div>
                            <!-- col end-->
                            <div class="col">
                                <p>Ремонтировали рейку на моей машине. Понравилось хорошее отношение к клиенту и профессиональный подход к ремонту. На работу дали гарантию и сделали скидку. Буду надеяться, что по вопросу рейки больше не прийдётся искать
                                    мастеров, спасибо!
                                </p>
                                <b>Владимир. Honda Accord</b>
                            </div>
                            <!-- col end-->
                            <div class="col">
                                <p>Ремонтировали рейку на моей машине. Понравилось хорошее отношение к клиенту и профессиональный подход к ремонту. На работу дали гарантию и сделали скидку. Буду надеяться, что по вопросу рейки больше не прийдётся искать
                                    мастеров, спасибо!
                                </p>
                                <b>Владимир. Honda Accord</b>
                            </div>
                            <!-- col end-->
                        </div>
                        <!-- slide end-->
                        <a href="#" class="btn btn_light btn-reviews">Оставить отзыв</a>
                    </div>
                    <!-- reviews-slider end-->
                    <div class="new-brand">
                        <div class="new-brand__row">
                            <div class="col-wrap col-wrap_50">
                                <div class="title">
                                    <a href="#">
                                        <span>Новости</span>
                                    </a>
                                </div>
                                <?php
                                    $args = array(
                                                'posts_per_page' => 2,
                                                'category' => '7,8'
                                            );
                                    $posts_array = get_posts( $args );
                                    $news_array = array('data' => array(),
                                                        'all_count' => count($posts_count));
                                    foreach ( $posts_array as $post ){
                                        $post_categories = wp_get_post_categories( $post->ID );
                                            
                                        $cat = get_category( $post_categories[0] );
                                            
                                            $one_new_ui = create_new_ui($post, 50);          
                                        echo $one_new_ui;                                 
                                    } //end foreach 
                                ?>
                            </div>
                            <div class="col-wrap col-wrap_50">
                                <div class="title">
                                    <span>Статьи</span>
                                </div>
                                <?php
                                    $args = array(
                                                'posts_per_page' => 2,
                                                'category' => '15,16',
                                                'offset' => $offset
                                            );
                                    $posts_array = get_posts( $args );
                                    $news_array = array('data' => array(),
                                                        'all_count' => count($posts_count));
                                    foreach ( $posts_array as $post ){
                                        $post_categories = wp_get_post_categories( $post->ID );
                                            
                                        $cat = get_category( $post_categories[0] );
                                        
                                        $one_new_ui = create_article_ui($post, 50);         
                                        echo $one_new_ui;                                 
                                    } //end foreach 
                                ?>
                            </div>
                        </div>
                        <!-- new-brand__row end-->
                    </div>
                    <!-- new-brand end-->
                    <div class="social-c">
                        <div class="social-c__row">
                            <div class="col col_25">
                                <div class="title">
                                    <span>Подпишись на наши обновления, и получи 5% скидку на услуги СТО</span>
                                </div>
                                <a href="#" class="btn btn_primary">Подписаться</a>
                            </div>
                            <div class="col col_25">
                                <div class="title">
                                    <span>Подпишись на наши обновления, и получи 5% скидку на услуги СТО</span>
                                </div>
                                <a href="#" class="btn btn_primary">Подписаться</a>
                            </div>
                            <div class="col col_25">
                                <div class="title">
                                    <span>Подпишись на наши обновления, и получи 5% скидку на услуги СТО</span>
                                </div>
                                <a href="#" class="btn btn_primary">Подписаться</a>
                            </div>
                            <div class="col col_25 social">
                                <div class="title">
                                    <span>Нас рекомендуют друзьям</span>
                                </div>
                                <div class="social-likes social-likes_vertical">
                                    <div class="facebook" title="Поделиться ссылкой на Фейсбуке">Facebook</div>
                                    <div class="twitter" title="Поделиться ссылкой в Твиттере">Twitter</div>
                                    <div class="plusone" title="Поделиться ссылкой в Гугл-плюсе">Google+</div>
                                </div>
                            </div>
                        </div>
                        <!-- social-c__row end-->
                    </div>
                    <!-- social-c end-->
                    <div class="auto-info">
                        <div class="title">
                            <span>Рулевое управление вашего авто</span>

                            <p>Автодоктор — лучший выбор</p>
                        </div>
                        <div class="text">
                            <p>Вас интересует рулевая рейка, тормозная система, аккумуляторы и прочие товары для авто? Все это вы можете купить прямо сейчас, сэкономив уйму времени! Интернет-магазин Doc-Service™ с радостью поможет вам избежать необходимости
                                посещать десятки магазинов.
                            </p>

                            <p>Вы можете заказать любой товар, не вставая со своего кресла, а наш курьер вовремя доставит покупку по указанному адресу. Вас интересует рулевая рейка, тормозная система, аккумуляторы и прочие товары для авто? Все это вы можете
                                купить прямо сейчас, сэкономив уйму времени! Интернет-магазин Doc-Service™ с радостью поможет вам избежать необходимости посещать десятки магазинов.</p>

                            <p>Вы можете заказать любой товар, не вставая со своего кресла, а наш курьер вовремя доставит покупку по указанному адресу.</p>
                        </div>
                        <div class="btn-wrap align-center">
                            <a href="#" class="btn btn_light">Хочу знать больше</a>

                        </div>
                    </div>
                    <!-- auto-info end-->
                </div>
                <!-- wrap-center end-->
            </div>
            <div class="revices-popup">
                <div class="revices-popup__close"></div>
                <div class="title">
                    <span>
                        Расскажите о своих впечатлениях
                        <br/>о нашем сервисе
                    </span>
                </div>
                <form action="#" class="revices-form">
                    <div class="row">
                        <textarea name="name" id="" cols="30" rows="10" placeholder="Оставьте ваш отзыв"></textarea>
                        <input type="text" class="inp" placeholder="Ваше имя">
                        <input type="text" class="inp" placeholder="Электронная почта">
                    </div>
                    <!-- row end-->
                    <div class="row">
                        <div class="row_i">
                            <div class="col col_50">
                                <select class="select-inp" data-placeholder="Марка автомобиля">
                                    <option></option>
                                    <option value="WY">Марка автомобиля</option>
                                    <option value="AL">Марка автомобиля</option>
                                    <option value="AL">Марка автомобиля</option>
                                </select>
                            </div>
                            <div class="col col_50">
                                <select class="select-inp" data-placeholder="Модель">
                                    <option></option>
                                    <option value="WY">Модель</option>
                                    <option value="AL">Модель</option>
                                    <option value="AL">Модель</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <!-- row end-->
                    <div class="row">
                        <div class="soc">
                            <p>Войти используя</p>
                            <div class="social-likes" data-counters="no">
                                <div class="facebook" title="Поделиться ссылкой на Фейсбуке">Facebook</div>
                                <div class="vkontakte" title="Поделиться ссылкой во Вконтакте">Вконтакте</div>
                                <div class="plusone" title="Поделиться ссылкой в Гугл-плюсе">Google+</div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <a href="#" class="btn btn_dang">Оставить отзыв</a>
                    </div>
                </form>
            </div>

            <div class="rev-thank">
                <div class="revices-popup__close">

                </div>
                <span>Спасибо!</span>
            </div>

            <?php include "footer.php"; ?>
        </div>
        
    </div>


</body>
