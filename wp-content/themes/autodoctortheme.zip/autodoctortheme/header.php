<!doctype html>

<head>
    <meta charset="utf-8">
    <title></title>
    <meta name="format-detection" content="telephone=no">
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="<?php echo esc_url( get_template_directory_uri() ); ?>/static/css/main.min.css" rel="stylesheet" type="text/css">
    <link rel="icon" type="image/png" href="<?php echo esc_url( get_template_directory_uri() ); ?>/fav.png">

    <script type='text/javascript'>
        var myajax = {"url":"<?php get_home_url(); ?>\/my_orders\/autodoctor\/wordpress\/wp-admin\/admin-ajax.php"};
    </script>
    <script type="text/javascript" src="<?php echo esc_url( get_template_directory_uri() ); ?>/static/js/jquery-2.1.4.js"></script>
    <script type="text/javascript" src="<?php echo esc_url( get_template_directory_uri() ); ?>/static/js/wu_main.js"></script>
    <script type="text/javascript" src="<?php echo esc_url( get_template_directory_uri() ); ?>/static/js/separate-js/modernizr.custom.17797.js"></script>
    <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/static/js/main.js"></script>

    <script type="text/javascript" src="<?php echo esc_url( get_template_directory_uri() ); ?>/static/js/separate-js/pikaday.js"></script>
    <script type="text/javascript" src="<?php echo esc_url( get_template_directory_uri() ); ?>/static/js/separate-js/start.js"></script>
    <script type="text/javascript" src="<?php echo esc_url( get_template_directory_uri() ); ?>/static/js/separate-js/cart.js"></script>
    <!--[if lt IE 9]>
    <script src="js/html5shiv-3.7.2.min.js"></script>
    <![endif]-->
</head>

<body>

    <div class="our">

        <div class="mob-nav">
            <div class="mob-nav__i">
                <ul class="nav-a">
                    <li>
                        <a href="#">Корзина</a>
                        <span class="bag">12</span>
                    </li>
                    <li>
                        <a href="#">Каталог
                            <span class="icon-arrow"></span>
                        </a>
                        <ul>
                            <li>
                                <a href="#">Замена Рулевого управления
                                </a>
                            </li>
                            <li>
                                <a href="#">Развал- схождение</a>
                            </li>
                            <li>
                                <a href="#">Ремонт ходовой</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="<?php echo get_option('home'); ?>/services">Услуги СТО
                            <span class="icon-arrow"></span>
                        </a>
                        <ul>
                            <li>
                                <a href="#">Замена Рулевого управления
                                </a>
                            </li>
                            <li>
                                <a href="#">Развал- схождение</a>
                            </li>
                            <li>
                                <a href="#">Ремонт ходовой</a>
                            </li>
                        </ul>
                    </li>
                </ul>
                <ul class="nav-b">
                    <li>
                        <a href="<?php echo get_option('home'); ?>/about">О нас</a>
                    </li>
                    <li>
                        <a href="#">Обмен</a>
                    </li>
                    <li>
                        <a href="<?php echo get_option('home'); ?>/delivery">Доставка и оплата</a>
                    </li>
                    <li>
                        <a href="<?php echo get_option('home'); ?>/all-news">Новости</a>
                    </li>
                    <li>
                        <a href="#">Контакты</a>
                    </li>
                    <li class="search-mob">
                        <a href="<?php echo get_option('home'); ?>/contact">Поиск</a>
                    </li>
                    <li class="reg">
                        <a href="#">Войти</a>
                    </li>
                    <li class="reg2">
                        <a href="#">Зарегистрироваться</a>
                    </li>
                </ul>
            </div>
        </div>





        <div class="our-wrap">
            <header class="header-main">

                <div class="burger">
                    <div class="burger_i">
                        <span class="top"></span>
                        <span class="center"></span>
                        <span class="bottom"></span>
                    </div>
                </div>

                <div class="header-top">
                    <div class="wrap-center">
                        <ul class="nav">
                            <li>
                                <a href="<?php echo get_option('home'); ?>/about">О нас</a>
                            </li>
                            <li>
                                <a href="#">Обмен</a>
                            </li>
                            <li>
                                <a href="<?php echo get_option('home'); ?>/delivery">Доставка и оплата</a>
                            </li>
                            <li>
                                <a href="<?php echo get_option('home'); ?>/all-news">Новости</a>
                            </li>
                            <li>
                                <a href="<?php echo get_option('home'); ?>/all-articles">Статьи</a>
                            </li>
                            <li>
                                <a href="<?php echo get_option('home'); ?>/contact">Контакты</a>
                            </li>
                        </ul>
                        <div class="header-top__info">
                            <a href="#" class="tel">(048) 772-08-50
                                <span class="icon-arrow"></span>
                            </a>
                            <a href="#" class="reg">
                                <span class="icon-key text-red"></span>Вход</a>
                        </div>
                    </div>

                </div>
                <div class="header-main__i">
                    <div class="sub-reg">
                        <div class="sub-reg_i">
                            <div class="title">
                                <span>
                                    Вход в интернет-магазин
                                </span>
                            </div>
                            <div class="row">
                                <div class="col">
                                    <input type="text" class="inp" placeholder="Ваша электронная почта" />
                                    <input type="text" class="inp" placeholder="Пароль" />
                                    <a href="#" class="pass">Напомнить пароль?</a>

                                    <div class="check">
                                        <input type="checkbox" id="cbtest" />
                                        <label for="cbtest" class="check-box">
                                            <i></i>
                                            <p>Запомнить меня</p>
                                        </label>
                                    </div>
                                    <div class="btns">
                                        <a href="#" class="btn btn_dang">Войти</a>
                                        <a href="#" class="cancel">Отмена</a>
                                    </div>
                                </div>

                                <div class="col col_soc">
                                    <div class="item">
                                        <span>
                                            или
                                        </span>
                                    </div>
                                    <p>Войти как пользователь</p>
                                    <a href="#" class="btn btn_vk">Вконтакте</a>
                                    <a href="#" class="btn btn_f">Facebook</a>
                                    <a href="#" class="btn btn_light-g">Зарегистироваться</a>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="sub-reg2">
                        <div class="prev-m">
                            <span>Вернуться →</span>
                        </div>
                        <div class="sub-reg_i">
                            <div class="title">
                                <span>
                                    Зарегистироваться
                                </span>
                            </div>
                            <p>Вы можете зарегистрироваться с помощью учетных записей социальных сетей</p>

                            <div class="btns">
                                <a href="#" class="btn btn_vk">Вконтакте</a>
                                <a href="#" class="btn btn_f">Facebook</a>
                            </div>
                            <div class="either">
                                <span>или</span>
                            </div>
                            <div class="row">
                                <div class="col">
                                    <input type="text" class="inp" placeholder="Имя" />
                                    <input type="text" class="inp" placeholder="Ваша электронная почта" />
                                    <input type="text" class="inp" placeholder="Пароль" />
                                    <a href="#" class="btn btn_dang">Зарегистироваться</a>
                                </div>
                                <div class="agreement">
                                    <span>Нажимая на кнопку «Зарегистирироваться», вы подверждаете свое согласие с условием предоставления услуг (
                                        <a href="#">пользовательское соглашение</a>)</span>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="sub-reg3">
                        <div class="prev-m">
                            <span>Вернуться →</span>
                        </div>
                        <div class="sub-reg_i">
                            <div class="title">
                                <span>
                                    Вход в интернет-магазин
                                </span>
                            </div>
                            <p>Войти как пользователь</p>

                            <div class="btns">
                                <a href="#" class="btn btn_vk">Вконтакте</a>
                                <a href="#" class="btn btn_f">Facebook</a>
                            </div>
                            <div class="either">
                                <span>или</span>
                            </div>
                            <div class="row">
                                <div class="col">
                                    <input type="text" class="inp" placeholder="Ваша электронная почта" />
                                    <input type="text" class="inp" placeholder="Пароль" />
                                    <a href="#" class="btn btn_dang">Войти</a>
                                </div>
                                <div class="pass">
                                    <a href="#">Напомнить пароль?</a>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="pass-reg">
                        <div class="prev-m">
                            <span>Вернуться →</span>
                        </div>
                        <div class="sub-reg_i">
                            <div class="title">
                                <span>
                                    Вход в интернет-магазин
                                </span>
                            </div>
                            <p>Восстановить пароль</p>


                            <div class="row">
                                <div class="col">
                                    <input type="text" class="inp" placeholder="Ваша электронная почта" />

                                    <a href="#" class="btn btn_dang">Получить временный пароль</a>
                                </div>
                                <div class="pass">
                                    <a href="#">Я вспомнил свой пароль</a>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="sub-social">
                        <div class="title">
                            <span>Автодоктор лого</span>
                        </div>
                        <b>Войти как пользователь</b>
                        <div class="btns">
                            <a href="#" class="btn btn_vk">Вконтакте</a>
                            <a href="#" class="btn btn_f">Facebook</a>
                        </div>
                        <div class="line">
                            <span>или</span>
                        </div>
                        <form action="#">
                            <input type="text" class="inp" placeholder="Ваша электронная почта" />
                            <input type="text" class="inp" placeholder="Пароль" />
                            <div class="btn btn_dang">
                                <input type="text" />Войти</div>
                            <a href="#" class="pass">Напомнить пароль?</a>
                        </form>
                    </div>
                    <div class="search-popup">
                        <div class="close">
                            <span class="line1"></span>
                            <span class="line2"></span>
                        </div>
                        <div class="row">
                            <input type="text" placeholder="Поиск" class="inp" />
                            <a href="#" class="btn btn_dang">Поиск</a>
                        </div>
                    </div>
                    <div class="wrap-center">
                        <div class="header-main__i__row">
                            <a href="<?php echo get_option('home'); ?>" class="logo">
                                <i></i>
                                <span>Автодоктор</span>
                            </a>

                            <div class="inp-row">
                                <input type="text" class="inp" placeholder="Быстрый поиск" />
                                <span class="inp-search icon-search text-red"></span>
                            </div>
                            <div class="wrap-bag bag-none">
                                <a href="#" class="bag">
                                    <i>
                                        <span></span>
                                    </i>Корзина</a>
                                <div class="sub-bag">
                                    <div class="icon"></div>
                                    <b>Ваша корзина пуста</b>
                                    <p>Добавляйте понравившиеся товары в корзину</p>
                                </div>
                            </div>

                        </div>
                        <!-- header-main__i__row end-->
                        <div class="header-main__i__nav">
                            <ul>
                                <li>
                                    <a href="#">Рулевые рейки
                                        <span class="icon-arrow"></span>
                                    </a>
                                    <div class="sub-menu">
                                        <div class="col">
                                            <ul>
                                                <li>
                                                    <a href="#">
                                                        <h2>Заголовок первого уровня</h2>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#">Заголовок второго уровня</a>
                                                </li>
                                                <li>
                                                    <a href="#">Заголовок второго уровня</a>
                                                </li>
                                            </ul>
                                            <ul>
                                                <li>
                                                    <a href="#">
                                                        <h2>Заголовок первого уровня</h2>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#">Заголовок второго уровня</a>
                                                </li>
                                                <li>
                                                    <a href="#">Заголовок второго уровня</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="col">
                                            <ul>
                                                <li>
                                                    <a href="#">
                                                        <h2>Заголовок первого уровня</h2>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#">Заголовок второго уровня</a>
                                                </li>
                                                <li>
                                                    <a href="#">Заголовок второго уровня</a>
                                                </li>
                                            </ul>
                                            <ul>
                                                <li>
                                                    <a href="#">
                                                        <h2>Заголовок первого уровня</h2>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#">Заголовок второго уровня</a>
                                                </li>
                                                <li>
                                                    <a href="#">Заголовок второго уровня</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="col">
                                            <ul>
                                                <li>
                                                    <a href="#">
                                                        <h2>Заголовок первого уровня</h2>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#">Заголовок второго уровня</a>
                                                </li>
                                                <li>
                                                    <a href="#">Заголовок второго уровня</a>
                                                </li>
                                            </ul>
                                            <ul>
                                                <li>
                                                    <a href="#">
                                                        <h2>Заголовок первого уровня</h2>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#">Заголовок второго уровня</a>
                                                </li>
                                                <li>
                                                    <a href="#">Заголовок второго уровня</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <!-- sub-menu end-->
                                </li>
                                <li>
                                    <a href="#">Тормоза Zimmermann
                                        <span class="icon-arrow"></span>
                                    </a>
                                    <div class="sub-menu">
                                        <div class="col">
                                            <ul>
                                                <li>
                                                    <a href="#">
                                                        <h2>Заголовок первого уровня</h2>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#">Заголовок второго уровня</a>
                                                </li>
                                                <li>
                                                    <a href="#">Заголовок второго уровня</a>
                                                </li>
                                            </ul>
                                            <ul>
                                                <li>
                                                    <a href="#">
                                                        <h2>Заголовок первого уровня</h2>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#">Заголовок второго уровня</a>
                                                </li>
                                                <li>
                                                    <a href="#">Заголовок второго уровня</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="col">
                                            <ul>
                                                <li>
                                                    <a href="#">
                                                        <h2>Заголовок первого уровня</h2>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#">Заголовок второго уровня</a>
                                                </li>
                                                <li>
                                                    <a href="#">Заголовок второго уровня</a>
                                                </li>
                                            </ul>
                                            <ul>
                                                <li>
                                                    <a href="#">
                                                        <h2>Заголовок первого уровня</h2>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#">Заголовок второго уровня</a>
                                                </li>
                                                <li>
                                                    <a href="#">Заголовок второго уровня</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="col">
                                            <ul>
                                                <li>
                                                    <a href="#">
                                                        <h2>Заголовок первого уровня</h2>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#">Заголовок второго уровня</a>
                                                </li>
                                                <li>
                                                    <a href="#">Заголовок второго уровня</a>
                                                </li>
                                            </ul>
                                            <ul>
                                                <li>
                                                    <a href="#">
                                                        <h2>Заголовок первого уровня</h2>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#">Заголовок второго уровня</a>
                                                </li>
                                                <li>
                                                    <a href="#">Заголовок второго уровня</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <!-- sub-menu end-->
                                </li>
                                <li>
                                    <a href="#">Подвеска H&R
                                        <span class="icon-arrow"></span>
                                    </a>
                                    <div class="sub-menu">
                                        <div class="col">
                                            <ul>
                                                <li>
                                                    <a href="#">
                                                        <h2>Заголовок первого уровня</h2>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#">Заголовок второго уровня</a>
                                                </li>
                                                <li>
                                                    <a href="#">Заголовок второго уровня</a>
                                                </li>
                                            </ul>
                                            <ul>
                                                <li>
                                                    <a href="#">
                                                        <h2>Заголовок первого уровня</h2>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#">Заголовок второго уровня</a>
                                                </li>
                                                <li>
                                                    <a href="#">Заголовок второго уровня</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="col">
                                            <ul>
                                                <li>
                                                    <a href="#">
                                                        <h2>Заголовок первого уровня</h2>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#">Заголовок второго уровня</a>
                                                </li>
                                                <li>
                                                    <a href="#">Заголовок второго уровня</a>
                                                </li>
                                            </ul>
                                            <ul>
                                                <li>
                                                    <a href="#">
                                                        <h2>Заголовок первого уровня</h2>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#">Заголовок второго уровня</a>
                                                </li>
                                                <li>
                                                    <a href="#">Заголовок второго уровня</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="col">
                                            <ul>
                                                <li>
                                                    <a href="#">
                                                        <h2>Заголовок первого уровня</h2>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#">Заголовок второго уровня</a>
                                                </li>
                                                <li>
                                                    <a href="#">Заголовок второго уровня</a>
                                                </li>
                                            </ul>
                                            <ul>
                                                <li>
                                                    <a href="#">
                                                        <h2>Заголовок первого уровня</h2>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#">Заголовок второго уровня</a>
                                                </li>
                                                <li>
                                                    <a href="#">Заголовок второго уровня</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <!-- sub-menu end-->
                                </li>
                                <li>
                                    <a href="<?php echo get_option('home'); ?>/services">Услуги СТО</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- header-main__i end-->

            </header>